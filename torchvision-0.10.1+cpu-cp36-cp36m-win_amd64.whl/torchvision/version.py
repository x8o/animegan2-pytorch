__version__ = '0.10.1+cpu'
git_version = 'ca1a6207fb17bb3e1f8411cc9d973c690a6f230a'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
